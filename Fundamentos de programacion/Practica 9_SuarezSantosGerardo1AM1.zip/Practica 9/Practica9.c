#include<stdio.h>
#include "Libreria.h"

int main(int arreg, char**arregv){
    
    start(arreg, arregv);
    
}